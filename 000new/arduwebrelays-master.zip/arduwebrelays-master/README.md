arduWebRelays
=============

EtherCard library used : https://github.com/jcw/ethercard

See in action here : http://youtu.be/wQedx-lqjfE

Parts used : 
 - Arduino Compatible Uno R3 : http://www.fasttech.com/products/1001700
 - AC/DC 2-Channel Relay Module : http://www.fasttech.com/products/1144100
 - ENC28J60 Ethernet LAN Network Module : http://www.fasttech.com/products/1174200
