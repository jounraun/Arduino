# CloudSensorEvoPlus
Cloud and rain sensor for Arduino
This is the Cloud Sensor Evo Plus.

For the Arduino Atmega 328, like the Nano, Uno etc.
You need the libraries (can be downloaded via the library handler in the arduino program)
- Onewire
- i2cmaster

See the "Cloud Sensor Evo Plus.doc" for more detail
