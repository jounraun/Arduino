print(adc.read(0))
