Random Nerd Tutorials
=====================

Random Nerd Tutorials is a blog where I share electronics projects, tutorials and reviews.

For complete project details visit: http://randomnerdtutorials.com/
