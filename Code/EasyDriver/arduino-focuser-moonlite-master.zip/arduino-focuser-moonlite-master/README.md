# arduino-focuser-moonlite

This is an implementation of a focuser for the Feathertouch MSM20 
bipolar stepper motor, driven with an AdaFruit v1 motor shield or clone.

Blog post here - http://orlygoingthirty.blogspot.sg/2014/04/arduino-based-motor-focuser-controller.html


