# Komakallio observatory automation

## Contents

- **server** - Observatory server that provides roof and weather data
- **observingconditions** - ObservingConditions ASCOM driver
- **roof** - Dome driver for roll-off roof
- **safety** - SafetyMonitor driver

