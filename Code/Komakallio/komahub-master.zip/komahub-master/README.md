KomaHub Remote Power Switch and Sensor Platform

EDA - schematics and board layout, made in Eagle

firmware - firmware code

tools - tools for operating komahub


